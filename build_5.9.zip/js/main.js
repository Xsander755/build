$(function() {
    lOadTabsRey();

});
var autor = 0;
var token = '8e08f29980d54010e345e7feec269216';
// document.addEventListener("contextmenu", function(e) {
//     e.preventDefault();
// }, false);