$(function() {
    lOadTabsRey();
    tImerOut();
});
var autor = 0;

