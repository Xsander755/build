$(function() {
    lOadTabsRey();

});
var autor = 0;
document.addEventListener("contextmenu", function(e) {
    e.preventDefault();
}, false);