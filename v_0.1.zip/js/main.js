$(function() {
    lOadTabsRey();
});
var autor = 0;